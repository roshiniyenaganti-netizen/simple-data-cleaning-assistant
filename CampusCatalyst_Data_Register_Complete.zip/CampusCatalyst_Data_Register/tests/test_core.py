"""Core regression tests."""
import json, tempfile, unittest
from pathlib import Path
from src.storage import RegisterStorage
from src.business_logic import RegisterService
from src.validators import validate_record
from src.importer import import_csv_text

VALID = {"record_id":"TST001","name":"Test Student","department":"CSE AI&ML",
         "year":1,"email":"test@example.com","attendance":80,"status":"Active"}

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.storage = RegisterStorage(Path(self.temp.name))
        self.service = RegisterService(self.storage)

    def tearDown(self):
        self.temp.cleanup()

    def test_validation_valid_and_invalid(self):
        self.assertEqual(validate_record(VALID), [])
        bad = {**VALID, "email":"nope", "year":"abc", "attendance":140}
        self.assertGreaterEqual(len(validate_record(bad)), 3)

    def test_blank_and_boundary_values(self):
        self.assertTrue(validate_record({**VALID, "name":""}))
        self.assertEqual(validate_record({**VALID, "attendance":0}), [])
        self.assertEqual(validate_record({**VALID, "attendance":100}), [])

    def test_add_search_update_delete(self):
        self.assertTrue(self.service.add_record(VALID)[0])
        self.assertEqual(len(self.service.search("Test")), 1)
        self.assertTrue(self.service.update_record("TST001", {"attendance":99})[0])
        self.assertEqual(self.service.list_records()[0]["attendance"], 99.0)
        self.assertTrue(self.service.delete_record("TST001"))
        self.assertEqual(self.service.list_records(), [])

    def test_duplicate_id_rejected(self):
        self.assertTrue(self.service.add_record(VALID)[0])
        self.assertFalse(self.service.add_record(VALID)[0])

    def test_corrupt_json_recovery(self):
        self.storage.json_path.write_text("{broken", encoding="utf-8")
        self.assertEqual(self.storage.load_records(), [])
        self.assertTrue(list(Path(self.temp.name).glob("register_corrupt_*.bak")))

    def test_sqlite_indexes_exist(self):
        self.storage.save_records([VALID])
        import sqlite3
        with sqlite3.connect(self.storage.db_path) as db:
            names = {r[1] for r in db.execute("PRAGMA index_list(records)")}
        self.assertIn("idx_records_name", names)
        self.assertIn("idx_records_department", names)

    def test_csv_row_errors(self):
        content = "record_id,name,department,year,email,attendance\nA1,Valid,CSE,1,a@b.com,90\nA2,,CSE,8,bad,120\n"
        good, errors = import_csv_text(content)
        self.assertEqual(len(good), 1)
        self.assertTrue(errors)

if __name__ == "__main__":
    unittest.main()
