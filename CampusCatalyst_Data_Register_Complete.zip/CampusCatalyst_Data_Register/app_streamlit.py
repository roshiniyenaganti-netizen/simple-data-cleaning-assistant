"""Native-component Streamlit UI; all data operations use src/."""
from pathlib import Path
import streamlit as st
from src.storage import RegisterStorage
from src.business_logic import RegisterService
from src.importer import import_csv_text
from src.exporters import export_csv, export_markdown

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="Campus Catalyst Register", page_icon="🎓", layout="wide")
st.title("🎓 Campus Catalyst")
st.subheader("Student Register Management System")
st.caption("A local-first register with validation, audit logging and indexed search.")

@st.cache_resource
def get_storage():
    return RegisterStorage(ROOT / "data")

storage = get_storage()
if "service" not in st.session_state:
    st.session_state.service = RegisterService(storage)
service: RegisterService = st.session_state.service

with st.sidebar:
    st.header("Workspace")
    page = st.radio("Navigate", ["Dashboard", "Records", "Add record", "Import CSV", "Reports"])
    st.caption("Backend: shared Python src/ package")

records = service.list_records()
if page == "Dashboard":
    a, b, c = st.columns(3)
    a.metric("Total records", len(records))
    b.metric("Departments", len({r["department"] for r in records}))
    c.metric("Average attendance", f"{sum(float(r['attendance']) for r in records)/len(records):.1f}%" if records else "—")
    st.markdown("### Recent records")
    st.dataframe(records[:10], use_container_width=True, hide_index=True)
    st.markdown("### Department distribution")
    counts = {}
    for row in records:
        counts[row["department"]] = counts.get(row["department"], 0) + 1
    st.bar_chart(counts)
elif page == "Records":
    query = st.text_input("Search by name, department or email")
    shown = service.search(query)
    st.caption(f"{len(shown)} matching record(s)")
    st.dataframe(shown, use_container_width=True, hide_index=True)
    with st.expander("Delete a record"):
        rid = st.text_input("Record ID to delete")
        if st.button("Delete", type="secondary"):
            if service.delete_record(rid.strip()):
                st.success("Record deleted.")
                st.rerun()
            else:
                st.error("Record ID not found.")
elif page == "Add record":
    with st.form("add_record"):
        rid = st.text_input("Record ID")
        name = st.text_input("Full name")
        dept = st.selectbox("Department", ["CSE AI&ML", "CSE", "ECE", "EEE", "IT", "Mechanical", "Civil"])
        year = st.selectbox("Year", [1, 2, 3, 4])
        email = st.text_input("Email")
        attendance = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, value=75.0)
        submitted = st.form_submit_button("Add student")
    if submitted:
        ok, errors = service.add_record({"record_id": rid, "name": name, "department": dept,
                                         "year": year, "email": email, "attendance": attendance,
                                         "status": "Active"})
        if ok:
            st.success("Student record added.")
            st.rerun()
        else:
            for error in errors:
                st.error(error)
elif page == "Import CSV":
    st.write("Required columns: record_id, name, department, year, email, attendance.")
    uploaded = st.file_uploader("Choose CSV file", type=["csv"])
    if uploaded is not None and st.button("Import valid rows"):
        imported, errors = import_csv_text(uploaded.getvalue().decode("utf-8-sig", errors="replace"))
        added = 0
        row_errors = []
        for row in imported:
            ok, issues = service.add_record(row)
            if ok:
                added += 1
            else:
                row_errors.extend(issues)
        st.success(f"Imported {added} row(s).")
        for error in errors + row_errors:
            st.warning(error)
elif page == "Reports":
    st.metric("Records available for export", len(records))
    st.download_button("Download CSV", export_csv(records), "register.csv", "text/csv")
    st.download_button("Download Markdown report", export_markdown(records), "register_report.md", "text/markdown")
    audit_path = ROOT / "data" / "audit_log.txt"
    audit_text = audit_path.read_text(encoding="utf-8") if audit_path.exists() else ""
    st.download_button("Download audit log", audit_text, "audit_log.txt", "text/plain")
    st.markdown("### Audit log preview")
    st.code("\\n".join(audit_text.splitlines()[-20:]) or "No audit events yet.")
