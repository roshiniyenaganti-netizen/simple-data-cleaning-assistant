# Campus Catalyst — Student Register

A Python 3.10+ mini-project with a standard-library backend, paginated ANSI CLI, native Streamlit UI, JSON/CSV persistence, SQLite indexes, audit trail, import/export, tests and CI.

## Requirements
- Python 3.10 or newer
- Streamlit only for the graphical UI (`pip install streamlit`)
- The CLI and core backend use only the Python standard library.

## Run the terminal app
```bash
python main.py
```

## Run the Streamlit web app
```bash
python -m pip install streamlit
streamlit run app_streamlit.py
```
Open the local URL printed by Streamlit (normally `http://localhost:8501`).

## Test
```bash
python -m unittest discover -s tests -v
```

## Project layout
```text
CampusCatalyst_Data_Register/
├── src/                    # Shared backend modules
├── data/                   # JSON, CSV, SQLite and audit log
├── reports/                # Export destination
├── tests/test_core.py
├── docs/API_REFERENCE.md
├── .github/workflows/ci.yml
├── .streamlit/config.toml
├── main.py
└── app_streamlit.py
```

## Notes
- On first run the app initializes a data store from the included seed JSON.
- Writes use temporary files followed by `os.replace`; a re-entrant thread lock and OS-level file lock guard writes.
- SQLite mirrors records and creates indexes for name, department and email searches.
- Corrupt JSON is moved to a timestamped `.bak` file and the register is reinitialized.
- CSV import reports invalid rows individually. CSV/Markdown/audit-log exports are available.
