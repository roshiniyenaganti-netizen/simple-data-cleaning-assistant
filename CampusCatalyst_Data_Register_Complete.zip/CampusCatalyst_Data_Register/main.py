"""Terminal entry point for Campus Catalyst."""
from pathlib import Path
from src.storage import RegisterStorage
from src.business_logic import RegisterService
from src.validators import safe_int, safe_text
from src.ui import banner, paginated_table, Ansi
from src.importer import import_csv_text
from src.exporters import export_csv, export_markdown

ROOT = Path(__file__).resolve().parent

def main() -> None:
    service = RegisterService(RegisterStorage(ROOT / "data"))
    while True:
        banner()
        print("1. View records       2. Add record")
        print("3. Search records     4. Update attendance")
        print("5. Delete record      6. Import CSV")
        print("7. Export reports     0. Exit")
        choice = input("\nSelect: ").strip()
        if choice == "0":
            print("Goodbye.")
            break
        elif choice == "1":
            paginated_table(service.list_records())
        elif choice == "2":
            row = {
                "record_id": safe_text("Record ID: "),
                "name": safe_text("Name: "),
                "department": safe_text("Department: "),
                "year": safe_int("Year (1-4): ", minimum=1, maximum=4),
                "email": safe_text("Email: "),
                "attendance": input("Attendance (0-100): ").strip(),
                "status": "Active",
            }
            ok, errors = service.add_record(row)
            print(Ansi.GREEN + "Record added." + Ansi.RESET if ok else Ansi.RED + "\n".join(errors) + Ansi.RESET)
        elif choice == "3":
            paginated_table(service.search(input("Search name/department/email: ").strip()))
        elif choice == "4":
            rid = safe_text("Record ID: ")
            attendance = input("New attendance (0-100): ").strip()
            ok, errors = service.update_record(rid, {"attendance": attendance})
            print("Updated." if ok else "\n".join(errors))
        elif choice == "5":
            print("Deleted." if service.delete_record(input("Record ID: ").strip()) else "ID not found.")
        elif choice == "6":
            path = Path(safe_text("CSV file path: ").strip('"'))
            try:
                rows, errors = import_csv_text(path.read_text(encoding="utf-8-sig"))
                for error in errors:
                    print(Ansi.YELLOW + error + Ansi.RESET)
                added = 0
                for row in rows:
                    ok, issues = service.add_record(row)
                    added += int(ok)
                    if not ok:
                        print("Import rejected:", "; ".join(issues))
                print(f"Imported {added} valid row(s); {len(errors)} row error(s).")
            except OSError as exc:
                print(f"Could not read file: {exc}")
        elif choice == "7":
            out = ROOT / "reports"
            out.mkdir(exist_ok=True)
            (out / "register.csv").write_text(export_csv(service.list_records()), encoding="utf-8")
            (out / "register.md").write_text(export_markdown(service.list_records()), encoding="utf-8")
            (out / "audit_log.txt").write_text((ROOT / "data" / "audit_log.txt").read_text(encoding="utf-8")
                                               if (ROOT / "data" / "audit_log.txt").exists() else "", encoding="utf-8")
            print(f"Reports saved in {out}.")
        else:
            print("Choose one of the listed options.")
        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()
