# API Reference

## `src.models`
- `RecordStatus`: string enum containing `Active`, `Inactive`, and `Needs Review`.
- `StudentRecord`: dataclass for a student row. `to_dict()` serializes it; `from_dict(row)` builds a typed record.

## `src.validators`
- `validate_record(row) -> list[str]`: validates ID, required text, year (1–4), email syntax and attendance (0–100). An empty list means valid.
- `safe_int(prompt, input_fn=input, minimum=None, maximum=None) -> int`: repeats until a valid bounded integer is entered.
- `safe_text(prompt, input_fn=input) -> str`: repeats until non-empty text is entered.

## `src.storage.RegisterStorage`
- `RegisterStorage(data_dir)`: creates JSON, CSV, SQLite and audit paths.
- `load_records() -> list[dict]`: loads JSON; missing or corrupt JSON is recovered automatically.
- `save_records(records) -> None`: atomically writes JSON and CSV, refreshes SQLite indexes and audits the save.
- `search_index(query) -> list[dict]`: indexed SQLite-backed search by name, department or email.
- `audit(message) -> None`: appends a timestamped audit event.
- `locked()`: context manager using an in-process re-entrant lock and OS file lock.

## `src.business_logic.RegisterService`
- `list_records()`: returns current records.
- `add_record(row) -> (bool, errors)`: validates and adds a unique record.
- `update_record(record_id, updates) -> (bool, errors)`: validates and updates an existing record.
- `delete_record(record_id) -> bool`: deletes by ID.
- `search(query)`: searches through the SQLite mirror.

## `src.importer`
- `import_csv_text(content) -> (valid_rows, errors)`: parses CSV, validates each row and returns row-numbered errors.

## `src.exporters`
- `export_csv(records) -> str`: CSV text.
- `export_markdown(records) -> str`: Markdown report.

## Entry points
- `python main.py`: ANSI terminal interface.
- `streamlit run app_streamlit.py`: Streamlit web interface.
- Both interfaces call the same `src/` service and storage modules.
