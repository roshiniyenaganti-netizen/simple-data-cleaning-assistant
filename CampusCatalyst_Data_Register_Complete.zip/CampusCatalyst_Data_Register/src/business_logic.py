"""Application use-cases shared by CLI and Streamlit."""
from __future__ import annotations
from typing import Any
from .models import StudentRecord
from .storage import RegisterStorage
from .validators import validate_record

class RegisterService:
    def __init__(self, storage: RegisterStorage):
        self.storage = storage
        self.records = storage.load_records()

    def list_records(self) -> list[dict[str, Any]]:
        return list(self.records)

    def add_record(self, row: dict[str, Any]) -> tuple[bool, list[str]]:
        errors = validate_record(row)
        if any(r["record_id"] == str(row.get("record_id", "")).strip() for r in self.records):
            errors.append("record_id already exists.")
        if errors:
            self.storage.audit("Rejected record: " + "; ".join(errors))
            return False, errors
        record = StudentRecord.from_dict(row).to_dict()
        self.records.append(record)
        self._save("Added record " + record["record_id"])
        return True, []

    def update_record(self, record_id: str, updates: dict[str, Any]) -> tuple[bool, list[str]]:
        for index, current in enumerate(self.records):
            if current["record_id"] == record_id:
                candidate = {**current, **updates}
                errors = validate_record(candidate)
                if errors:
                    return False, errors
                self.records[index] = StudentRecord.from_dict(candidate).to_dict()
                self._save("Updated record " + record_id)
                return True, []
        return False, ["Record ID was not found."]

    def delete_record(self, record_id: str) -> bool:
        before = len(self.records)
        self.records = [r for r in self.records if r["record_id"] != record_id]
        if len(self.records) == before:
            return False
        self._save("Deleted record " + record_id)
        return True

    def search(self, query: str) -> list[dict[str, Any]]:
        return self.storage.search_index(query) if query.strip() else self.list_records()

    def _save(self, action: str) -> None:
        self.storage.save_records(self.records)
        self.storage.audit(action)
