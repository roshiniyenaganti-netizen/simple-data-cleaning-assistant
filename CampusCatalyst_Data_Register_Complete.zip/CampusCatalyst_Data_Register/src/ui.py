"""ANSI terminal presentation and paginated table helpers."""
import os
from typing import Any

class Ansi:
    RESET = "\033[0m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"

def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")

def banner() -> None:
    print(f"{Ansi.CYAN}{Ansi.BOLD}\\n CAMPUS CATALYST | STUDENT REGISTER{Ansi.RESET}")
    print(f"{Ansi.CYAN}" + "─" * 68 + f"{Ansi.RESET}")

def paginated_table(records: list[dict[str, Any]], page_size: int = 8) -> None:
    if not records:
        print("No records to display.")
        return
    total_pages = (len(records) + page_size - 1) // page_size
    page = 0
    while True:
        start = page * page_size
        print(f"\nPage {page + 1}/{total_pages} · {len(records)} records")
        print(f"{'ID':<12} {'NAME':<20} {'DEPARTMENT':<18} {'YEAR':<5} {'ATTEND.':<8} STATUS")
        print("-" * 88)
        for row in records[start:start + page_size]:
            print(f"{str(row.get('record_id','')):<12.12} {str(row.get('name','')):<20.20} "
                  f"{str(row.get('department','')):<18.18} {str(row.get('year','')):<5} "
                  f"{str(row.get('attendance','')):<8} {row.get('status','')}")
        if total_pages == 1:
            break
        command = input("[N]ext / [P]revious / [Q]uit: ").strip().lower()
        if command == "n" and page < total_pages - 1:
            page += 1
        elif command == "p" and page > 0:
            page -= 1
        elif command == "q" or command == "":
            break
