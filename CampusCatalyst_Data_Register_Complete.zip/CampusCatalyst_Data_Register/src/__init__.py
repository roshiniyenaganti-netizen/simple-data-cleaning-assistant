"""Campus Catalyst data register package."""
