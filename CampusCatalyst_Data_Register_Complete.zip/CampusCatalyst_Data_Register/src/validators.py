"""Defensive validation helpers; invalid input never escapes as an exception."""
import re
from typing import Callable

ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,20}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")

def validate_record(row: dict[str, object]) -> list[str]:
    errors: list[str] = []
    rid = str(row.get("record_id", "")).strip()
    name = str(row.get("name", "")).strip()
    dept = str(row.get("department", "")).strip()
    email = str(row.get("email", "")).strip()
    try:
        year = int(str(row.get("year", "")).strip())
    except (TypeError, ValueError):
        year = -1
    try:
        attendance = float(str(row.get("attendance", "")).strip())
    except (TypeError, ValueError):
        attendance = -1
    if not ID_RE.fullmatch(rid):
        errors.append("record_id must be 2-20 letters, digits, '_' or '-'.")
    if not name or len(name) > 80:
        errors.append("name is required and must be at most 80 characters.")
    if not dept or len(dept) > 60:
        errors.append("department is required and must be at most 60 characters.")
    if year not in (1, 2, 3, 4):
        errors.append("year must be an integer from 1 to 4.")
    if not EMAIL_RE.fullmatch(email):
        errors.append("email format is invalid.")
    if not 0 <= attendance <= 100:
        errors.append("attendance must be between 0 and 100.")
    return errors

def safe_int(prompt: str, input_fn: Callable[[str], str] = input,
             minimum: int | None = None, maximum: int | None = None) -> int:
    while True:
        raw = input_fn(prompt).strip()
        try:
            value = int(raw)
            if minimum is not None and value < minimum:
                print(f"Enter a value >= {minimum}.")
                continue
            if maximum is not None and value > maximum:
                print(f"Enter a value <= {maximum}.")
                continue
            return value
        except ValueError:
            print("Please enter a whole number.")

def safe_text(prompt: str, input_fn: Callable[[str], str] = input) -> str:
    while True:
        value = input_fn(prompt).strip()
        if value:
            return value
        print("This field cannot be blank.")
