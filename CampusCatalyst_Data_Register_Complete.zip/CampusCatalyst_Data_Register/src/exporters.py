"""Markdown, CSV and audit-log export helpers."""
import csv, io
from datetime import datetime
from typing import Any

def export_csv(records: list[dict[str, Any]]) -> str:
    fields = ["record_id","name","department","year","email","attendance","status"]
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(records)
    return output.getvalue()

def export_markdown(records: list[dict[str, Any]]) -> str:
    lines = ["# Campus Catalyst Register Report", "",
             f"Generated: {datetime.now().astimezone().isoformat(timespec='seconds')}", "",
             f"**Total records:** {len(records)}", "",
             "| ID | Name | Department | Year | Attendance | Status |",
             "|---|---|---|---:|---:|---|"]
    for row in records:
        cells = [str(row.get(k, "")).replace("|", "\\\\|") for k in
                 ("record_id","name","department","year","attendance","status")]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"
