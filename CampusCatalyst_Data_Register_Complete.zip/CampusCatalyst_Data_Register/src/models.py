"""Typed domain models for the campus register."""
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any

class RecordStatus(str, Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"
    REVIEW = "Needs Review"

@dataclass
class StudentRecord:
    record_id: str
    name: str
    department: str
    year: int
    email: str
    attendance: float
    status: str = RecordStatus.ACTIVE.value

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "StudentRecord":
        return cls(
            record_id=str(row.get("record_id", "")),
            name=str(row.get("name", "")),
            department=str(row.get("department", "")),
            year=int(row.get("year", 1)),
            email=str(row.get("email", "")),
            attendance=float(row.get("attendance", 0)),
            status=str(row.get("status", RecordStatus.ACTIVE.value)),
        )
