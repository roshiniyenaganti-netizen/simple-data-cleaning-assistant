"""Thread/process-safe persistence, atomic JSON/CSV writes and SQLite index."""
from __future__ import annotations
import csv, json, os, sqlite3, tempfile, threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

try:
    import fcntl
except ImportError:  # Windows
    fcntl = None
try:
    import msvcrt
except ImportError:  # POSIX
    msvcrt = None

class RegisterStorage:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "register.json"
        self.csv_path = self.data_dir / "register.csv"
        self.db_path = self.data_dir / "register.sqlite3"
        self.audit_path = self.data_dir / "audit_log.txt"
        self.lock_path = self.data_dir / ".register.lock"
        self._thread_lock = threading.RLock()
        self._init_db()

    @contextmanager
    def locked(self) -> Iterator[None]:
        with self._thread_lock:
            with self.lock_path.open("a+b") as lock_file:
                if fcntl:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
                elif msvcrt:
                    lock_file.seek(0)
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)
                try:
                    yield
                finally:
                    if fcntl:
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                    elif msvcrt:
                        lock_file.seek(0)
                        msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)

    def _atomic_write(self, path: Path, writer) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                writer(handle)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def save_records(self, records: list[dict[str, Any]]) -> None:
        with self.locked():
            self._atomic_write(self.json_path, lambda f: json.dump(records, f, indent=2, ensure_ascii=False))
            fields = ["record_id", "name", "department", "year", "email", "attendance", "status"]
            def write_csv(handle):
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerows(records)
            self._atomic_write(self.csv_path, write_csv)
            self._replace_db(records)
            self.audit("Saved register to JSON, CSV and SQLite.")

    def load_records(self) -> list[dict[str, Any]]:
        # Read/archive under the lock, then initialize outside it to avoid
        # recursively acquiring the OS-level lock through save_records().
        missing = False
        corrupted: str | None = None
        with self.locked():
            try:
                with self.json_path.open(encoding="utf-8") as handle:
                    data = json.load(handle)
                if not isinstance(data, list):
                    raise json.JSONDecodeError("Root must be a list", "", 0)
                self._replace_db(data)
                return data
            except FileNotFoundError:
                missing = True
            except json.JSONDecodeError as exc:
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup = self.json_path.with_name(f"register_corrupt_{stamp}.bak")
                os.replace(self.json_path, backup)
                corrupted = f"Corrupt JSON archived as {backup.name}: {exc}"
        if missing:
            self.audit("Register JSON missing; initialized an empty register.")
        if corrupted:
            self.audit(corrupted)
        self.save_records([])
        return []

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=10)
        connection.execute("""CREATE TABLE IF NOT EXISTS records (
            record_id TEXT PRIMARY KEY, name TEXT, department TEXT,
            year INTEGER, email TEXT, attendance REAL, status TEXT)""")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_records_name ON records(name)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_records_department ON records(department)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_records_email ON records(email)")
        return connection

    def _init_db(self) -> None:
        with self._connect() as connection:
            connection.commit()

    def _replace_db(self, records: list[dict[str, Any]]) -> None:
        with self._connect() as connection:
            connection.execute("DELETE FROM records")
            connection.executemany(
                "INSERT OR REPLACE INTO records VALUES (?, ?, ?, ?, ?, ?, ?)",
                [(str(r.get("record_id","")), str(r.get("name","")), str(r.get("department","")),
                  int(r.get("year", 1)), str(r.get("email","")), float(r.get("attendance",0)),
                  str(r.get("status","Active"))) for r in records])
            connection.commit()

    def search_index(self, query: str) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT record_id,name,department,year,email,attendance,status FROM records "
                "WHERE name LIKE ? OR department LIKE ? OR email LIKE ? ORDER BY name",
                (f"%{query}%", f"%{query}%", f"%{query}%")).fetchall()
        keys = ["record_id","name","department","year","email","attendance","status"]
        return [dict(zip(keys, row)) for row in rows]

    def audit(self, message: str) -> None:
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        with self._thread_lock:
            with self.audit_path.open("a", encoding="utf-8") as handle:
                handle.write(f"[{stamp}] {message}\\n")
