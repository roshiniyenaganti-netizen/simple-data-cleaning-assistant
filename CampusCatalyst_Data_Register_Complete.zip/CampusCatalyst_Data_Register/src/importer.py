"""CSV import with row-level validation and error reporting."""
import csv, io
from typing import Any

from .validators import validate_record

def import_csv_text(content: str) -> tuple[list[dict[str, Any]], list[str]]:
    records: list[dict[str, Any]] = []
    errors: list[str] = []
    try:
        reader = csv.DictReader(io.StringIO(content))
        required = {"record_id","name","department","year","email","attendance"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            return [], ["CSV is missing required columns: " + ", ".join(sorted(required))]
        for line_number, raw in enumerate(reader, start=2):
            row: dict[str, Any] = {key: (value or "").strip() for key, value in raw.items() if key}
            row.setdefault("status", "Active")
            issues = validate_record(row)
            if issues:
                errors.append(f"Row {line_number}: " + "; ".join(issues))
            else:
                records.append(row)
    except csv.Error as exc:
        errors.append(f"CSV parsing error: {exc}")
    return records, errors
